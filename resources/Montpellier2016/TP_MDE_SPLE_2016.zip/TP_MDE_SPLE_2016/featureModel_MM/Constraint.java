package featureModel_MM;

public abstract class Constraint {
	
	public abstract String familiarSyntax();
	

}
