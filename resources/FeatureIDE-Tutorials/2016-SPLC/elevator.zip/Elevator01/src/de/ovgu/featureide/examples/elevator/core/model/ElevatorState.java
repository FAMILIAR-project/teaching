package de.ovgu.featureide.examples.elevator.core.model;

public enum ElevatorState { MOVING_UP, MOVING_DOWN, FLOORING }
